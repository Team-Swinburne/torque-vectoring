![IPG Logo](images/IPG_Logo.png)

# CMRosIF User's Guide for FS Autonomous

## Table of Contents

- [CMRosIF User's Guide for FS Autonomous](#cmrosif-users-guide-for-fs-autonomous)
  - [Table of Contents](#table-of-contents)
  - [1. **Introduction**](#1-introduction)
    - [1.1 **Installation Requirements**](#11-installation-requirements)
  - [2. **What's included?**](#2-whats-included)
  - [3. **Quick Start Guide**](#3-quick-start-guide)
  - [4. **How can I modify CMRosIF?**](#4-how-can-i-modify-cmrosif)
    - [4.1. **Publishing CarMaker Data to ROS**](#41-publishing-carmaker-data-to-ros)
    - [4.2. **Subscribing to ROS Data in CarMaker**](#42-subscribing-to-ros-data-in-carmaker)

---

## 1. **Introduction**

This project provides an example implementation of CarMaker with ROS (CMRosIF), which has been extended from the standard 'hellocm' example on the IPG Website (FAQ section). Please see the documentation for the standard CarMaker ROS Interface in the 'doc' folder of this project: **CMRosIF_UsersGuide.pdf**.

### 1.1 **Installation Requirements**

- Linux Ubuntu 18.04
  - *Project was developed using 18.04, but 16.04 should also be compatible.*
- ROS Melodic Morenia
  - *Project was developed using ROS Melodic, but ROS Kinetic should be compatible.*
- CarMaker Office (Linux) 10.1
  - See CarMaker Release Notes and Installation Guide for proper installation procedure.

  - Ensure the following step is taken (excerpt from CarMaker Installation Guide):

  ![CM Install Shortcut](images/CM_Linux_Install.png)

  - Other CarMaker versions can be used, but the project needs to be updated using the instructions in *CMRosIF_UsersGuide_Basic.pdf --> Section 4.1: Installation*.

---

## 2. **What's included?**

- Representative Vehicle Model
  - Vehicle Data for FS-AI ADS-DV
    - Electric Powertrain
    - Suspension, geometry, and mass data
    - Some data approximations made, to be improved in future updates.
  - Sensors:
    - Front Camera Sensor
      - Raw Video Data Streams via **Camera RSI Sensor**
        - RGB Output
        - Depth Output
      - 'High Fidelity' Camera Model via **Camera HiFi Sensor**
      - Ground Truth Object List via **Object Sensor**
    - Front Lidar Sensor via **Lidar RSI Sensor**
    - Sensor data is published to ROS over separate topics:
      - pointcloud
      - Camera
      - ObjectList
  - Vehicle Control Interface
    - Allows user to send ROS commands to CarMaker and control the vehicle.
- Example Track Drive TestRun
- Cone Placement Script
  - Automatic placement of FS-AI cones around a given track.

---

## 3. **Quick Start Guide**

1. Run the build script `build_cmrosif.sh` in a terminal (located on the top level of the project). This will build the ROS workspace (located in `<project>/ros/ros1_ws`), then the CarMaker application (located in `<project>/src`).
2. Open CarMaker with the `CMStart.sh` script on the top level of the project.
3. Start the ROS workspace and CarMaker application from: **Main CarMaker GUI --> Extras --> CMRosIF --> Launch & Start Application**. This will launch the ROS workspace from the `hellocm.launch` file, then Start and connect to the CarMaker application.
4. Open the example 'TrackDrive' TestRun from the **Main GUI --> File --> Open --> Project --> FSD_TrackDrive**.
5. Start the simulation with the green Start button in the CarMaker GUI. ROS data should be published and subscribed to by CMRosIF from the following topics. The main topics in this extension to CMRosIF are **/Camera**, **/ObjectList**, **/pointcloud**, and **/VehicleControl**.

```console
    foo@bar:~$ source ./ros/ros1_ws/devel/setup.bash; rostopic list
      /Camera
      /ObjectList
      /VehicleControl
      /clicked_point
      /clock
      /hellocm/cm2ext
      /hellocm/ext2cm
      /initialpose
      /move_base_simple/goal
      /pointcloud
      /rosout
      /rosout_agg
      /tf
      /tf_static
```

![Simulation Visualization in rViz + IPGMovie](images/QuickStart_Simulation_rVizMovie.png)
6. If raw camera streams are desired, multiple CameraRSI sensors can be defined and mounted on the CarMaker vehicle frame. Currently these cameras can be either RGB (`Coloration mode: Realistic`) or Depth (`Coloration mode: Depth linear gray`). Every active camera will automaticall launch a separate external Raw Signal Data Stream client (ROS node) that recieves the raw data from the Camera RSI Sensors (aka Raw Signal Data Stream) in CarMaker, then publishes it to standard ROS image messages in the topics **/<CAMERA_NAME>**.

```cpp
// ~Line 967
/* Do a system call to roslaunch and launch the ROS node */
sprintf(sbuf, "roslaunch carmaker_rsds_client carmaker_rsds_client.launch \
camera_no:=%d \
camera_name:=%s \
rsds_port:=%d \
param_trans_rot:=[%f,%f,%f,%f,%f,%f] \
fov_deg:=%f \
width:=%f \
height:=%f &",
camera_no,
Camera.name,
Camera.Socket,
Camera.pos[0],Camera.pos[1],Camera.pos[2],Camera.rot[0],Camera.rot[1],Camera.rot[2],
Camera.FoV,
Camera.Resolution[0],
Camera.Resolution[1]);
int SystemReturn_Err = system(sbuf);
```

![Raw Signal Data Stream Client Start](images/RSDS_Streams_RQT.png)

For more information and troubleshooting on the RSDS ROS client nodes, see the corresponding README file in `<project>/ros/ros1_ws/src/carmaker_rsds_client`.

---

## 4. **How can I modify CMRosIF?**

The CarMaker ROS Interface is meant to be modified by the user to publish and subscribe to data they need in ROS and CarMaker. Most code changes in this example project are made in the following file:

```console
<project>/ros/ros1_ws/src/hellocm_cmnode/src/CMNode_ROS1_HelloCM.cpp
```

This file is the source code for the *internal* node in CMRosIF, used to communicate with all external ROS nodes via topics, services, etc. This node can be thought of as the port in and out of CarMaker. The standard example only publishes 'hello' messages back and forth between the CMNode and an example external node, along with simulation clock and an initialization topic to start the co-simulation with ROS.

### 4.1. **Publishing CarMaker Data to ROS**

In general, the process used to publish CarMaker data in ROS topics takes the following modifications in *CMNode_ROS1_HelloCM.cpp*:

1. Include necessary header files for CarMaker quantities and ROS message definitions at the beginning of the file.

    ```cpp
    // ~Line 48
    //CarMaker Header File Includes
    #include "Vehicle.h"
    #include "Vehicle/Sensor_LidarRSI.h"
    #include "Vehicle/Sensor_Object.h"
    #include "Vehicle/Sensor_Camera.h"
    #include "infoc.h"
    #include "InfoUtils.h"
    #include "Log.h"
    #include <math.h>
    #include "DataDict.h"
    #include "SimCore.h"
    #include "Car/Car.h"
    #include "Car/Brake.h"
    #include "DrivMan.h"
    #include "VehicleControl.h"
    #include "Traffic.h"

    /* ROS */
    #include "cmrosutils/CMRosUtils.h"    /* Node independent templates, ...*/
    #include "cmrosutils/CMRosIF_Utils.h" /* Only for CarMaker ROS Node!!! Functions are located in library for CarMaker ROS Interface */
    #include "cmrosutils/CMRemote.h"      /* Basic service for CarMaker remote from ROS */
    #include "sensor_msgs/PointCloud.h"
    #include "visualization_msgs/MarkerArray.h"
    #include "tf2_geometry_msgs/tf2_geometry_msgs.h"
    #include "tf2_ros/transform_broadcaster.h"
    #include "tf2_ros/static_transform_broadcaster.h"
    #include <angles/angles.h>
    #include "vehiclecontrol_msgs/VehicleControl_msgs.h"
    #include "camera_msgs/Camera_DetectionArray.h"
    ```

2. Create corresponding object using template publisher `tRosIF_TpcPub`.

    ```cpp
    // ~Line 166
    struct {
        struct {
            tRosIF_TpcSub<hellocm_msgs::Ext2CM> Ext2CM; /* For this example also used for Synchronization */
            tRosIF_TpcSub<vehiclecontrol_msgs::VehicleControl_msgs> VC;
        } Sub; /*!< Topics to be subscribed */

        struct {
            tRosIF_TpcPub<hellocm_msgs::CM2Ext> CM2Ext;
            tRosIF_TpcPub<sensor_msgs::PointCloud> Lidar;
            tRosIF_TpcPub<camera_msgs::Camera_DetectionArray> Camera;
            tRosIF_TpcPub<visualization_msgs::MarkerArray> ObjectList;

            /*!< CarMaker can be working as ROS Time Server providing simulation time
             *   starting at 0 for each TestRun */
            tRosIF_TpcPub<rosgraph_msgs::Clock> Clock;
        } Pub; /*!< Topics to be published */
    } Topics; /*!< ROS Topics used by this Node */
    ```

3. Advertise topic to be published in `CMRosIF_CMNode_Init()` and create CMRosIF Job.

    ```cpp
    // ~Line 565
    strcpy(sbuf, "/pointcloud");
    LOG("  -> Publish '%s'", sbuf);
    CMNode.Topics.Pub.Lidar.Pub         = node->advertise<sensor_msgs::PointCloud>(sbuf, static_cast<uint>(CMNode.Cfg.QueuePub));
    CMNode.Topics.Pub.Lidar.Job         = CMCRJob_Create("pointcloud");

    strcpy(sbuf, "/ObjectList");
    LOG("  -> Publish '%s'", sbuf);
    CMNode.Topics.Pub.ObjectList.Pub    = node->advertise<visualization_msgs::MarkerArray>(sbuf, static_cast<uint>(CMNode.Cfg.QueuePub));
    CMNode.Topics.Pub.ObjectList.Job    = CMCRJob_Create("ObjectList");
    
    strcpy(sbuf, "/Camera");
    LOG("  -> Publish '%s'", sbuf);
    CMNode.Topics.Pub.Camera.Pub         = node->advertise<camera_msgs::Camera_DetectionArray>(sbuf, static_cast<uint>(CMNode.Cfg.QueuePub));
    CMNode.Topics.Pub.Camera.Job         = CMCRJob_Create("Camera");
    ```

4. *Optionally* Read relevant CarMaker sensor parameters in `CMRosIF_CMNode_TestRun_Start_atBegin()` using CarMaker's InfoFile Read functions (see Programmer's Guide for more information on these functions).

    ```cpp
    // ~Line 777
    //Read sensor info from Vehicle InfoFile
    tInfos *Inf_Vehicle = nullptr;
    Inf_Vehicle = InfoNew();
    
    const char *FName;
    FName = InfoGetFilename(SimCore.Vhcl.Inf);

    //Log("FName = %s\n", FName);

    int VehicleInfo_Err = iRead2(&err, Inf_Vehicle, FName, "SensorReadCode");

    if (VehicleInfo_Err == 0) {

        tf2::Quaternion q;

        CMNode.Misc.nSensors        = iGetIntOpt(Inf_Vehicle, "Sensor.N", 0);

        /* Object Sensor */
        idxP = -1;
        for (idxS = 0; idxS < CMNode.Misc.nSensors; idxS++) {
            sprintf(sbuf, "Sensor.%d.Ref.Param", idxS);
            ref = iGetIntOpt(Inf_Vehicle, sbuf, 0);
            sprintf(sbuf, "Sensor.Param.%d.Type", ref);
            str = iGetStrOpt(Inf_Vehicle, sbuf, "");
            if (!strcmp(str, "Object")) {
                /* If the Object sensor is found, get its index and exit loop */
                idxP = ref;
                break;
            }
        }
        if (idxP != -1) {
            /* Store Object sensor parameters */
            sprintf(sbuf, "Sensor.%d.Active", idxS);
            CMNode.Sensor.Object.Active                   = iGetIntOpt(Inf_Vehicle, sbuf, 0);
            sprintf(sbuf, "Sensor.%d.pos", idxS);
            CMNode.Sensor.Object.pos                      = iGetFixedTableOpt2(Inf_Vehicle, sbuf, def3c, 3, 1);
            sprintf(sbuf, "Sensor.%d.rot", idxS);
            CMNode.Sensor.Object.rot                      = iGetFixedTableOpt2(Inf_Vehicle, sbuf, def3c, 3, 1);
            sprintf(sbuf, "Sensor.Param.%d.UpdRate", idxP);
            CMNode.Sensor.Object.UpdRate                  = iGetIntOpt(Inf_Vehicle, sbuf, 100);
            sprintf(sbuf, "Sensor.Param.%d.CycleOffset", idxP);
            CMNode.Sensor.Object.nCycleOffset             = iGetIntOpt(Inf_Vehicle, sbuf, 0);

            /* Pass Object sensor parameters to job */
            q.setRPY(angles::from_degrees(CMNode.Sensor.Object.rot[0]), 
                     angles::from_degrees(CMNode.Sensor.Object.rot[1]), 
                     angles::from_degrees(CMNode.Sensor.Object.rot[2]));
            CMNode.TF.ObjectList.transform.rotation = tf2::toMsg(q);
            CMNode.TF.ObjectList.transform.translation = tf2::toMsg(tf2::Vector3(
                CMNode.Sensor.Object.pos[0], 
                CMNode.Sensor.Object.pos[1], 
                CMNode.Sensor.Object.pos[2]));
            sprintf(sbuf, "Sensor.%d.name", idxS);
            CMNode.TF.ObjectList.child_frame_id = iGetStrOpt(Inf_Vehicle, sbuf, "OB00");
            sprintf(sbuf, "Sensor.%d.Mounting", idxS);
            CMNode.TF.ObjectList.header.frame_id = iGetStrOpt(Inf_Vehicle, sbuf, "Fr1A");
            CMNode.Topics.Pub.ObjectList.CycleTime = CMNode.Sensor.Object.UpdRate;
            CMNode.Topics.Pub.ObjectList.CycleOffset = CMNode.Sensor.Object.nCycleOffset;
        } else {
            CMNode.Sensor.Object.Active                   = 0;
        }
        ...
    ```

5. Initialize the CMRosIF Job in the function `CMRosIF_CMNode_TestRun_Start_atBegin()`.

    ```cpp
    // ~Line 1117
    //Ideal Object list topic init
    job       = CMNode.Topics.Pub.ObjectList.Job;
    cycletime = CMNode.Topics.Pub.ObjectList.CycleTime;
    cycleoff  = CMNode.Topics.Pub.ObjectList.CycleOffset;

    CMCRJob_Init(job, cycleoff, cycletime, CMCRJob_Mode_Ext);
    ```

6. Package CarMaker sensor data into ROS topic (usually in `CMRosIF_CMNode_Calc()`).

    ```cpp
    // ~Line 1542
    if (CMNode.Sensor.Object.Active) {
        //Object Sensor --> MarkerArray
        if ((rv = CMCRJob_DoPrep(CMNode.Topics.Pub.ObjectList.Job, CMNode.CycleNoRel, 1, nullptr, nullptr)) < CMCRJob_RV_OK) {
            LogErrF(EC_Sim, "CMNode: Error on DoPrep for Job '%s'! rv=%s", CMCRJob_GetName(CMNode.Topics.Pub.ObjectList.Job), CMCRJob_RVStr(rv));
        } else {
            visualization_msgs::Marker markers;
            CMNode.Topics.Pub.ObjectList.Msg.markers.clear();
            ros::Time object_sensor_stamp = ros::Time(ObjectSensor[0].TimeStamp);

            // display objects with a duration of the topics cycle time,
            // so rviz forgets them when they are not being published anymore
            // (80 + milliseconds) to seconds
            ros::Duration object_viz_time = ros::Duration(0.001 * (80+CMNode.Topics.Pub.ObjectList.CycleTime));

            for (int j = 0; j < ObjectSensor[0].nObsvObjects; j++) {

                int obj_id = ObjectSensor[0].ObsvObjects[j];
                tObjectSensorObj *pOSO = ObjectSensor_GetObjectByObjId(0, obj_id);
                tTrafficObj *pObj = Traffic_GetByObjId(obj_id);

                markers.header.frame_id = CMNode.TF.ObjectList.child_frame_id;
                markers.id = pOSO->ObjId;
                markers.type = visualization_msgs::Marker::CUBE;
                markers.action = visualization_msgs::Marker::ADD;
                markers.lifetime = object_viz_time;
                markers.header.stamp = object_sensor_stamp;

                markers.scale.x = pOSO->l;
                markers.scale.y = pOSO->w;
                markers.scale.z = pOSO->h;


                // white
                markers.color.a = 0.7f;
                markers.color.r = 1.0;
                markers.color.g = 1.0;
                markers.color.b = 1.0;

                if (pOSO->dtct || pOSO->InLane){
                    if (!std::strcmp(pObj->Cfg.Info, "Right Yellow Cone")) {
                        // yellow
                        markers.color.r = 1.0;
                        markers.color.g = 1.0;
                        markers.color.b = 0.0;
                    } else if (!std::strcmp(pObj->Cfg.Info, "Left Blue Cone")) {
                        // blue
                        markers.color.r = 0.0;
                        markers.color.g = 0.3;
                        markers.color.b = 1.0;
                    } else {
                        // orange start cones
                        markers.color.r = 1.0;
                        markers.color.g = 0.6;
                        markers.color.b = 0.0;
                    }
                }

                // object rotation as quaternion
                tf2::Quaternion rotation;
                rotation.setRPY(pOSO->RefPnt.r_zyx[0], pOSO->RefPnt.r_zyx[1], pOSO->RefPnt.r_zyx[2]);

                // apply rotation to vector pointing to the object's center
                tf2::Vector3 obj_center = tf2::quatRotate(rotation, tf2::Vector3(0.5 * pOSO->l, 0, 0));

                markers.pose.position.x = pOSO->RefPnt.ds[0] + obj_center.getX();
                markers.pose.position.y = pOSO->RefPnt.ds[1] + obj_center.getY();
                markers.pose.position.z = pOSO->RefPnt.ds[2] + obj_center.getZ();
                markers.pose.orientation = tf2::toMsg(rotation);

                CMNode.Topics.Pub.ObjectList.Msg.markers.push_back(markers);

            }
        }
    }
    ...
    ```

7. Publish topic when desired (usually in `CMRosIF_CMNode_Out()`).

    ```cpp
    // ~Line 1733
    if (CMNode.Sensor.Object.Active) {
        //Send out Ideal (ObjectSensor) Object List
        auto out_objectlist = &CMNode.Topics.Pub.ObjectList;

        if ((rv = CMCRJob_DoJob(out_objectlist->Job, CMNode.CycleNoRel, 1, nullptr, nullptr)) != CMCRJob_RV_DoNothing
                && rv != CMCRJob_RV_DoSomething) {
            LogErrF(EC_Sim, "CMNode: Error on DoJob for Job '%s'! rv=%s",CMCRJob_GetName(out_objectlist->Job), CMCRJob_RVStr(rv));
        } else if (rv == CMCRJob_RV_DoSomething) {

        out_objectlist->Pub.publish(out_objectlist->Msg);
        
        /* Remember cycle for debugging */
        CMNode.Model.CycleLastOut = CMNode.CycleNoRel;
        }
    }
    ```

The CMRosIF 'Job' functions used are not required, but they help with error handling and cyclical publishing, so that data packaging and publishing doesn't need to be done every simulation cycle. This would cause potentially unnecessarily high publishing rates that reduce simulation efficiency.

### 4.2. **Subscribing to ROS Data in CarMaker**

1. Include necessary header files for CarMaker quantities and ROS message definitions (see previous code snippets).

    ```cpp
    // ~Line 58
    #include "VehicleControl.h"
    ...
    #include "vehiclecontrol_msgs/VehicleControl_msgs.h"
    ```

2. Create corresponding object using template subscriber `tRosIF_TpcSub` (see previous code).

    ```cpp
    // ~Line 169
    tRosIF_TpcSub<vehiclecontrol_msgs::VehicleControl_msgs> VC;
    ```

3. Create Subscriber Callback function.

    ```cpp
    // ~Line 305
    //Vehicle Control Subscriber Callback
    static void
    cmnode_VehicleControl_CB_TpcIn(const vehiclecontrol_msgs::VehicleControl_msgs::ConstPtr &msg) {

        int rv;
        auto in = &CMNode.Topics.Sub.VC;

        in->Msg.use_vc          = msg->use_vc;

        in->Msg.selector_ctrl   = msg->selector_ctrl;

        in->Msg.gas             = msg->gas;
        in->Msg.brake           = msg->brake;

        in->Msg.steer_ang       = msg->steer_ang;
        in->Msg.steer_ang_vel   = msg->steer_ang_vel;
        in->Msg.steer_ang_acc   = msg->steer_ang_acc;
    ...
    ```

4. Advertise topic to be subscribed in `CMRosIF_CMNode_Init()` and create CMRosIF Job in `CMRosIF_CMNode_Init()`.

    ```cpp
    // ~Line 596
    //Vehicle Control Sub
    strcpy(sbuf, "/VehicleControl");
    LOG("  -> Subscribe '%s'", sbuf);
    CMNode.Topics.Sub.VC.Sub = node->subscribe(sbuf, static_cast<uint>(CMNode.Cfg.QueueSub),cmnode_VehicleControl_CB_TpcIn);
    CMNode.Topics.Sub.VC.Job = CMCRJob_Create("VehicleControl");
    CMNode.Topics.Sub.VC.CycleTime = 1;
    CMNode.Topics.Sub.VC.CycleOffset = 0;
    ```

5. Initialize the CMRosIF Job in the function `CMRosIF_CMNode_TestRun_Start_atBegin()`.

    ```cpp
    // ~Line 1132
    //Vehicle Control Sub
    job         = CMNode.Topics.Sub.VC.Job;
    cycletime   = CMNode.Topics.Sub.VC.CycleTime;
    cycleoff    = CMNode.Topics.Sub.VC.CycleOffset;

    CMCRJob_Init(job, cycleoff, cycletime, CMCRJob_Mode_Default);
    ```

6. Use subscriber callback function to recieve data when desired, usually in `CMRosIF_CMNode_VehicleControl_Calc()`. Assign subscribed data to CarMaker quantities, if applicable.

    ```cpp
    // ~Line 1391
    int
    CMRosIF_CMNode_VehicleControl_Calc (double dt)
    {
    /* Only do anything if simulation is running */
    if (CMNode.Cfg.Mode == CMNode_Mode_Disabled || SimCore.State != SCState_Simulate) {
        return 0;
    }

    /* Put your code here */
        //Assign VC to DM quants in case not written to...
    VehicleControl.SelectorCtrl     = DrivMan.SelectorCtrl;

    VehicleControl.Gas              = DrivMan.Gas;
    VehicleControl.Brake            = DrivMan.Brake;

    VehicleControl.Steering.Ang     = DrivMan.Steering.Ang;
    VehicleControl.Steering.AngVel  = DrivMan.Steering.AngVel;
    VehicleControl.Steering.AngAcc  = DrivMan.Steering.AngAcc;

    /*    
    VehicleControl.Key              = DrivMan.Key;
    VehicleControl.SST              = DrivMan.SST;

    VehicleControl.Lights.Daytime   = DrivMan.Lights.MainLight;
    VehicleControl.Lights.FogFrontL = DrivMan.Lights.FogFront;
    VehicleControl.Lights.FogFrontR = DrivMan.Lights.FogFront;
    VehicleControl.Lights.FogRear   = DrivMan.Lights.FogRear;
    VehicleControl.Lights.HighBeam  = DrivMan.Lights.HighBeam;
    */

    int rv;
    auto sub = &CMNode.Topics.Sub.VC;

    if ((rv = CMCRJob_DoJob(sub->Job, CMNode.CycleNoRel, 1, nullptr, nullptr)) != CMCRJob_RV_DoNothing && rv != CMCRJob_RV_DoSomething) {

        Log("CMNode: Error on DoJob for Job '%s'! rv=%s\n\n", CMCRJob_GetName(sub->Job), CMCRJob_RVStr(rv));

    } else if (rv == CMCRJob_RV_DoSomething) {

        if (SimCore.Time < 0.001) {
            CMNode.Topics.Sub.VC.Msg.use_vc == 0; //Reset back to DM at beginning of simulation...
        }

        if (CMNode.Topics.Sub.VC.Msg.use_vc == 1) {

            //Assign ROS Topic to CM Vehicle Control Quantities
            //-->Automatic transmission PRNDL selection
            VehicleControl.SelectorCtrl     = CMNode.Topics.Sub.VC.Msg.selector_ctrl;

            //-->Pedal Positions (add clutch if needed for manual)
            VehicleControl.Gas              = CMNode.Topics.Sub.VC.Msg.gas;
            VehicleControl.Brake            = CMNode.Topics.Sub.VC.Msg.brake;

            //-->Steer by angle inputs (add steer torque if using GenTorque model)
            VehicleControl.Steering.Ang     = CMNode.Topics.Sub.VC.Msg.steer_ang;
            VehicleControl.Steering.AngVel  = CMNode.Topics.Sub.VC.Msg.steer_ang_vel;
            VehicleControl.Steering.AngAcc  = CMNode.Topics.Sub.VC.Msg.steer_ang_acc;
   ...
   ```

In the case of the Vehicle Control interface, a custom ROS message is used (see the package `vehiclecontrol_msgs` for more info. This message requires the user to set the flag '**use_vc**' in order to write to CarMaker vehicle control quantities. When the user wants to take over control of the vehicle, this boolean must be written to *1 (True)*, or else Vehicle Control quantities cannot be written to. In the reverse scenario, when the user wants to stop writing to Vehicle Control quantities and maybe return control to IPGDriver, set this '**use_vc**' flag to *0 (False)*.

---

## 5. **Miscellaneous**

### 5.1 Lidar Sensor Specifics

There are a few things to note about the Lidar RSI sensor and how its data is being published to the ROS `pointcloud` topic. The PointCloud1 message type is used, and may be updated to PointCloud2 in the future.

Compared to other sensor data, the Lidar RSI sensor needs its *beam table* to be looped over so that each outgoing laser beam in the map can be linked to a horizontal and vertical angle. From these angles and the lidar's length or time of flight, a point cloud can be constructed and packed into the pointcloud message type (see CMRosIF_CMNode_Calc() function for pointcloud packaging code).

The example code relies on a variable called tableSize, which is defined globally in CMNode, and needs to be changed when the number of beams changes in the CarMaker sensor. If the number of horizontal or vertical 'beams' in the Lidar RSI sensor changes, this variable needs to be updated (and still multiplied by 6), then the ROS workspace needs to be recompiled via `build_cmrosif.sh`.

```cpp
// ~Line 75
/*
    beams_h * beams_v = tableSize
    Ex: 300 * 50 = 15000
*/
//Lidar RSI --> Number of Beams
static const unsigned int tableSize = 15000 * 6;
```

![Lidar Beams Calc](images/Lidar_Beams.png)

The solution is not the very elegant, and is planned to be updated in the future so that code recompilation is not necessary when the number of beams is changed.
